// This file is generated automatically by `useSvgSpriteTemplate.ts`. DO NOT EDIT IT.
(function () {
  var svgCode = '$SVGSPRITE';
  if (document.body) {
    document.body.insertAdjacentHTML('afterbegin', svgCode);
  } else {
    document.addEventListener('DOMContentLoaded', function () {
      document.body.insertAdjacentHTML('afterbegin', svgCode);
    });
  }
}());
