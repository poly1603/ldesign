# tdesign-icons-react-native

## 0.0.3

### Patch Changes

- fix: fix lock-on icon path

## 0.0.2

### Patch Changes

- feat: add `list-numbered` icon, optimize path of `lock-off`;
- fix: fix `chart-column` naming;

## 0.0.1

- feat: release 0.0.1
