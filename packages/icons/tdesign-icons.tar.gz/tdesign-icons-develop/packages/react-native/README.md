# TDesign Icons for React Natve

## 安装

- `npm i tdesign-icons-react-native`

## 使用

```js
import { CloseIcon, TimeIcon } from "tdesign-icons-react-native";

<CloseIcon />;
```
