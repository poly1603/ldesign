# CHANGELOG

## 0.1.10 `2023-03-07`

### Features

- manifest 文件增加 path 属性

## 0.1.9 `2022-12-05`

### Features

- 新增 `minus-rectangle-filled` 图标

## 0.1.7 `2022-08-10`

### Features

- 新增`qq`、`wechat`、`wecom`、`relativity`和`pin-filled`等图标

## 0.1.6 `2022-07-20`

### Features

- 新增`image-error`图标

## 0.1.5 `2022-07-12`

### Features

- 新增`mirror`和`rotation`图标

## 0.1.4 `2022-06-24`

### Features

- 新增`rollfront`图标

## 0.1.3 `2022-05-19`

### Bug Fixes

- 修复组件 HostBinding 绑定 style 属性优先级过高的问题
- 修复添加样式引用

## 0.1.2 `2022-05-13`

### Bug Fixes

- 将 HostBinding 相关 protected 变量设置为 public

## 0.1.0 `2022-05-09`

### Features

- 新增`file-icon`图标，优化部分图标路径

## 0.0.3 `2022-03-17`

### Bug Fixes

- 将 `t-icon` `t-icon-*` 组件宿主元素 `display` 属性设置为 `inline-block`，防止内外高度不一致导致图标无法正确居中对齐
