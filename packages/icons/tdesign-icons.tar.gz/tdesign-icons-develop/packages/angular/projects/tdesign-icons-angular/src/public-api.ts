export * from './lib/tdesign-icons-angular.service';
export * from './lib/tdesign-icons-angular.component';
export * from './lib/tdesign-icons-angular.module';

export * from './lib/icons';
export { manifest } from './lib/manifest';
