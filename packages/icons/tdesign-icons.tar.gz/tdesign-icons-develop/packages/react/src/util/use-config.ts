import { useContext } from 'react';
import ConfigContext from './config-context';

export default () => useContext(ConfigContext);
