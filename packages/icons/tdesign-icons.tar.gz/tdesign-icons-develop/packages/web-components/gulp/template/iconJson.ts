// @ts-ignore
export default $SVGJSON;
