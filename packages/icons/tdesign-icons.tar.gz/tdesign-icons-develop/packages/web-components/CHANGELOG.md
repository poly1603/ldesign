# tdesign-icons-web-components

## 0.2.7

### Patch Changes

- fix: add LICENSE

## 0.2.6

### Patch Changes

- feat: 新增 `logo-miniprogram`、`logo-cnb`、`seal`、`quote` 图标
  fix: 优化多个文件相关图标的绘制效果，修复 `gesture-right-slip` 的绘制问题

## 0.2.5

### Patch Changes

- fix: fix path covert bug

## 0.2.4

### Patch Changes

- feat: 新增 logo-alipay、logo-behance-filled 等图标，修改 logo-wecom 图标，移除不合理的 logo-wecom-filled 图标

## 0.2.3

### Patch Changes

- fix: fix sideEffect

## 0.2.2

### Patch Changes

- fix: fix filled-icon naming

## 0.2.1

### Patch Changes

- fix: fix video-camera naming

## 0.2.0

### Major Changes

- feat: 新增 907 个新图标
- feat: `blockchain` 重命名改为`transform-1`,`gesture-pray-1`重命名为`gesture-open`,
  `gesture-ranslation-1`重命名为`wave-bye`, `gesture-up-1`重命名为`gesture-typing`,`gesture-up-2`重命名为`gesture-right-slip`,`logo-wechat`重命名为`logo-wechat-stroke-filled`
- feat: 移除`tree-list`、`logo-adobe-photoshop-1` 图标

## 0.1.5

### Patch Changes

- feat: add innerClass and innerStyle

## 0.1.4

### Patch Changes

- fix: fix: upgrade omi to fix icon repeated rendering

## 0.1.3

### Patch Changes

- fix: fix lock-on icon path

## 0.1.2

### Patch Changes

- fix: fix icon center position and duplicated class

## 0.1.1

### Minor Changes

- fix: fix `clip-rule` and `fill-rule` bug

## 0.1.0

### Major Changes

- release tdesign-icons-web-components `v0.1.0`
