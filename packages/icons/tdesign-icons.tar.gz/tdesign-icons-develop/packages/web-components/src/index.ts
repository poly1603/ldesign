import './svg-sprite';

export * from './manifest';
export * from './global-config';
export type { SpriteIconProps } from './svg-sprite';
