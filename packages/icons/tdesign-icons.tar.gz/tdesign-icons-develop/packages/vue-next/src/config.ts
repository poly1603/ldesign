export const prefix = 't';

export default {
  prefix,
};
