import _Icon from './svg-sprite';

export const Icon = _Icon;
export default Icon;
