import _Icon from './icon';

export const IconFont = _Icon;
export default IconFont;
