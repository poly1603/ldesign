# TDesign Icons View

## 介绍

- 一个用于解决跨所有框架展示 Icon 的 基于 web component 的包。

## 安装

- `npm i tdesign-icons-view`

## 使用

```js
import "tdesign-icons-view";

// 开发侧 展示复制name和<NameIcon />的操作
<td-icons-view show-type="develop" />;
// 设计侧 展示复制svg和下载svg的操作
<td-icons-view show-type="design" />;
```
