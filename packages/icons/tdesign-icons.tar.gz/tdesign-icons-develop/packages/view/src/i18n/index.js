import enUS from './en-US.js';
import zhCN from './zh-CN.js';

export {
  enUS,
  zhCN,
};
