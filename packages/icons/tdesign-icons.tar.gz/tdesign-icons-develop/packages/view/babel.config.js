module.exports = {
  presets: [['@vue/cli-plugin-babel/preset', { jsx: false }],
    ['@vue/babel-preset-jsx', { compositionAPI: true }]],
};
