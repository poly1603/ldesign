declare module 'gulp-iconfont';
declare module 'gulp-iconfont-css';
declare module 'gulp-header';
declare module '@svgr/core';
declare module 'oslllo-svg-fixer';
